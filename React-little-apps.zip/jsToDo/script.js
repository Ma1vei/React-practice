const input = document.getElementById('input');
const tasks = document.getElementById('forTasks');

const all = document.querySelector('.all')

let a = 0;

input.addEventListener('keypress', (e) => {
    const li = document.createElement('li');
    if(e.key == 'Enter') {
        if(e.target.value == 0) {
            alert('ВВЕДИТЕ ЗАДАНИЕ')
        } else {
            a++;
            const c = `task${a}`;
            li.id = c
            li.innerHTML = `${e.target.value} 
            <span>
                <input class="checkbox" id="${c}" type="checkbox"></input> 
                <button class="btn-task" id="${c}">delete</button>
            </span>`
            tasks.appendChild(li)
            e.target.value = ''
           
        }
        const btn_task = document.querySelectorAll('.btn-task')
        const btndel = btn_task[btn_task.length - 1]
        btndel.addEventListener('click', (e) => {
            const allLi = document.getElementsByTagName('li')
            for(let i = 0; i < allLi.length; i++){
                
                if(allLi[i].id == e.target.id) {
                    const removeLi = allLi[i]
                    removeLi.remove();
                    break;
                }
            }
        })
        const checkbox = document.querySelectorAll('.checkbox')
        const chckbox = checkbox[checkbox.length - 1]
        chckbox.addEventListener('click', (e) => {
            const allLi = document.getElementsByTagName('li')
            for(let i = 0; i < allLi.length; i++) {
                if(allLi[i].id == e.target.id) {
                    const firstLi = allLi[0]
                    const newLi = allLi[i]
                    tasks.insertBefore(newLi, firstLi)
                    break;
                }
            }
        })
    }

})


all.addEventListener('click', (e) => {
    const checkbox = document.querySelectorAll('.checkbox')
    console.log(checkbox)
    for(let j = 0; j < checkbox.length; j++) {
        checkbox[j].checked = !checkbox[j].checked;
    }
})