import React from 'react'

export default function BlockCross({onBtnClick, children, disabled}) {

  return (
    <button style={{width: '100px',
        height: '100px', 
        border: 'solid',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'inherit',
        fontSize: '90px'
      }}  
        disabled = {disabled}
        onClick={onBtnClick}
        
    >
        {children}
        </button>
  )
}
