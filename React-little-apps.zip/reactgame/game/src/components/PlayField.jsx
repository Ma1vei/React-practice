import React from 'react'
import { useState } from 'react'
import BlockCross from './BlockCross'

export default function PlayField() {
    const [block, setBlock] = useState(['', '', '', '', '', '', '', '', ''])
    const [player, setPlayer] = useState(false)
    const [play, setPlay] = useState(false)
    const [dis, setDis] = useState([true, true, true, true, true, true, true, true, true,])
    const [winner, setWinner] = useState('ожидает')
    const [counterX, setCounterX] = useState(0)
    const [counterO, setCounterO] = useState(0)
    const [tie, setTie] = useState(0)

    const checkWinner = (newBlock) => {
        const winCombination = [
            [0,1,2],
            [3,4,5],
            [6,7,8],
            [0,3,6],
            [1,4,7],
            [2,5,8],
            [0,4,8],
            [6,4,2]
        ];
        let checkTie = false
        for(let combination of winCombination) {
            let [a, b, c] = combination
            if(newBlock[a] && newBlock[a] == newBlock[b] && newBlock[a] == newBlock[c] && newBlock[a] != '') {
                setWinner(player ? 'O' : 'X')
                player ? setCounterO(prev => prev + 1) : setCounterX(prev => prev + 1)
                setBlock(['', '', '', '', '', '', '', '', ''])
                setDis([true, true, true, true, true, true, true, true, true,])
                setTie(0)
                setPlay(prev => !prev)
            } else {
                setTie(prev => prev+1)
                console.log(tie)
                if(tie == 64) {
                    checkTie = true
                }
            }
        }
        if(checkTie) {
            setBlock(['', '', '', '', '', '', '', '', ''])
            alert('НИЧЬЯ')
            setTie(0)
            setPlay(prev => !prev)
        }
        
    }

    const handleClick = (index) => {
        const newBlock = [...block]
        const disData = [...dis]
        if(player) {
            newBlock[index] = 'O'
            setBlock(newBlock)
            disData[index] = true
            setDis(disData)
            setPlayer(prev => !prev)
            checkWinner(newBlock)
        } else {
            newBlock[index] = 'X';
            setBlock(newBlock);
            disData[index] = true
            setDis(disData)
            setPlayer(prev => !prev)
            checkWinner(newBlock)
        }
    }

  return (
    <div className="playfield">
        <div className="row" style={{display: 'flex', width: '350px', flexWrap: 'wrap'}}>
            {block.map((element, index) => {
                return ( 
                    <BlockCross key={index} disabled={dis[index]} onBtnClick={() => handleClick(index)}>{element}</BlockCross>
                )
            })}
        </div>
        <div style={{marginTop: '20px'}}>ВЫЙГРАЛ: {`${winner}`}</div>
        <div style={{marginTop: '20px'}}>СЧЁТ: {counterX}:{counterO}</div>
        <button style={{marginTop: '20px'}} onClick={() => {
            !play ? setPlay(prev => !prev) : 0
            !play ? setDis([false, false, false, false, false, false, false, false, false,]) : 0
            !play ? setWinner('ожидает') : 0
            !play ? setPlayer(false) : 0
            
        }}>PLAY</button>
    </div>
  )
}

