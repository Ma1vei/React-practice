import React from 'react'
import PlayField from './components/PlayField'

export default function App() {
  return (
    <>
        <PlayField></PlayField>
    </>
  )
}
