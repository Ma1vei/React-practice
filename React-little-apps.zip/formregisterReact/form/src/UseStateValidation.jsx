import React from 'react'

export default function UseStateValidation() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [emailDirty, setEmailDirty] = useState(false)
  const [passwordDirty, setPasswordDirty] = useState(false)
  const [emailErr, setEmailErr] = useState('Email не должен быть пустым')
  const [passwordErr, setPasswordErr] = useState('Пароль не должен быть пустым')

  const [btn, setBtn] = useState(false)

  useEffect(() => {
    if(emailErr || passwordErr) {
      setBtn(false)
    } else {
      setBtn(true)
    }
  }, [passwordErr, emailErr])

  const emailHandle = (e) => {
    setEmail(e.target.value)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!emailRegex.test(e.target.value)) {
      setEmailErr('Email не коректен')
    } else {
      setEmailErr('')
    }
  }
  
  const passwordHandle = (e) => {
    setPassword(e.target.value)
    if(e.target.value.length < 3 || e.target.value.length > 8) {
      setPasswordErr('Password не коректен')
    } else {
      setPasswordErr('')
    }
  }

  const blurHandle = (e) => {
    switch(e.target.name) {
      case 'email' :
        setEmailDirty(true)
        break
      case 'password' :
        setPasswordDirty(true)
        break
    }
  }
  return (
    <form action="" style={{display: 'flex', flexDirection: 'column'}}>
        <h1>Регистрация</h1>
        {(emailDirty && emailErr) && <div>{emailErr}</div>}
        <input onChange={(e) => emailHandle(e)} defaultValue={email} onBlur={(e) => blurHandle(e)} type="text" name='email'/>
        {(passwordErr && passwordDirty) && <div>{passwordErr}</div>}
        <input onChange={(e) => passwordHandle(e)} defaultValue={password} onBlur={(e) => blurHandle(e)} type="pasword" name='password'/>
        <button disabled={!btn}>Registration</button>
    </form>
  )
}
