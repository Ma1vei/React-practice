import { useEffect, useState } from 'react'
import './App.css'


const useValid = (value, validations) => {

  const [isEmpty, setEmpty] = useState(true)
  const [length, setLength] = useState(false)
  const [emailErr, setEmailErr] = useState(true)
  const [btn, setBtn] = useState(false)

  useEffect (() => {
    for(const validation in validations) {
      switch (validation) {
        case 'minlength':
          value.length < validations[validation] ? setLength(true) : setLength(false)
        break;
        case 'isEmpty' :
          value ? setEmpty(false) : setEmpty(true)
        break;
        case 'isEmail' :
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          emailRegex.test(value) ? setEmailErr(false) : setEmailErr(true)
        break;
      }
    }
  }, [value])

  useEffect(() => {
    if(emailErr || isEmpty || length) {
      setBtn(false)
    } else {
      setBtn(true)
    }
  }, [isEmpty, length, emailErr])

  return {
    isEmpty,
    length,
    emailErr,
    btn
  }
}

const useInput = (initialValue, validations) => {
  const [value, setValue] = useState(initialValue)
  const [isDirty, setIsDirty] = useState(false)
  const valid = useValid(value, validations)

  const onChange = (e) => {
    setValue(e.target.value)
  }

  const onBlur = (e) => {
    setIsDirty(true)
  }

  return {
    value, 
    onChange,
    onBlur,
    isDirty,
    ...valid
  }
}


function App() {
  const email = useInput('', {isEmpty: true, length: 3, isEmail: true})
  const password = useInput('', {isEmpty: true, length: 5})

  return (
    <>
      <form action="" style={{display: 'flex', flexDirection: 'column'}}>
        {(email.isDirty && email.isEmpty) && <p style={{color: 'red'}}>Поле не может быть пустым</p>}
        {(email.isDirty && email.emailErr) && <p style={{color: 'red'}}>Не коректный эмейл</p>}
        <input style={{marginBottom: '20px'}} type="text" defaultValue={email.value} onBlur={e => email.onBlur(e)} onChange={e => email.onChange(e)}/>
        {(password.isDirty && password.isEmpty) && <p style={{color: 'red'}}>Поле не может быть пустым</p>}
        <input type="password" defaultValue={password.value} onBlur={e => password.onBlur(e)} onChange={e => password.onChange(e)}/>
        <button disabled={!email.btn}>REGISTRATION</button>
      </form>
    </>
  )
}

export default App