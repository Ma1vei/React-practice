import React from 'react'
import Header from './Components/Header'
import Footer from './Components/Footer'
import Items from './Components/Items'
import Categories from './Components/Categories'
import ShowFullItem from './Components/ShowFullItem'

class App extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      orders: [

      ],
      currentItems: [],
      items: [
        {
          id: 1,
          title: 'Стул',
          img: '1.jpg',
          desc: 'lorem aeweq', 
          category: 'chairs',
          price: 50
        },
        {
          id: 2,
          title: 'Стул',
          img: '3.jpg',
          desc: 'lorem asdsfeweq', 
          category: 'chairs',
          price: 40
        },
        {
          id: 3,
          title: 'Стол',
          img: '4.jpg',
          desc: 'lorem aewfffeq', 
          category: 'tables',
          price: 502
        },
        {
          id: 4,
          title: 'Шкаф',
          img: '5.jpg',
          desc: 'lorem aeweq', 
          category: 'furnitures',
          price: 100
        },
        {
          id: 6,
          title: 'Кровать',
          img: '6.jpg',
          desc: 'lвorem aeweq', 
          category: 'beds',
          price: 50
        },
      ],
      ShowFullItem: false,
      fullItem: {}
    }
    this.state.currentItems = this.state.items
    this.addOrder = this.addOrder.bind(this)
    this.deleteOrder = this.deleteOrder.bind(this)
    this.chooseCategory = this.chooseCategory.bind(this)
    this.onItem = this.onItem.bind(this)
  }


  render() {
    return (
      <>
        <div className='wrapp'>
          <Header orders={this.state.orders} deleteOrder={this.deleteOrder}></Header>
          <Categories chooseCategory={this.chooseCategory}></Categories>
          <Items onItem={this.onItem} items={this.state.currentItems} onAdd={this.addOrder}></Items>

          {this.state.ShowFullItem && <ShowFullItem onItem={this.onItem} onAdd={this.addOrder} item={this.state.fullItem}></ShowFullItem>}
          <Footer></Footer>
        </div>
      </>
    ) 
  }

  onItem(item) {
    this.setState({fullItem: item})
    this.setState({ShowFullItem: !this.state.ShowFullItem})
  }

  chooseCategory(category) {
    if(category === 'all') { 
      this.setState({currentItems: this.state.items})
      return
    }
    
    this.setState({currentItems: this.state.items.filter(e => e.category === category)})
  }


  deleteOrder(id) {
    this.setState({orders: this.state.orders.filter(e => e.id != id)})
  }

  addOrder(item) {
    let peremennay = false
    this.state.orders.forEach(e => {
      if(e.id === item.id) {
        peremennay = true
      }
    })

    if(!peremennay) this.setState({orders: [...this.state.orders, item]}) 
  }

}

export default App
