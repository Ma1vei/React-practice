import React from 'react'

export default function Footer() {
  return (
    <footer>
        <p>Все права защищены &copy;</p>
    </footer>
  )
}
