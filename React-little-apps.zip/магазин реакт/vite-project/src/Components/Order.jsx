import React, { Component } from 'react'
import { FaTrash } from 'react-icons/fa'

export class Order extends Component {
  render() {
    return (
        <div className='item'>
            <img src={"./img/" + this.props.item.img} alt="" />
            <h2>{this.props.item.title}</h2>
            <p className='price'>{this.props.item.price}$</p>
            <FaTrash className='del' onClick={() => this.props.deleteOrder(this.props.item.id)}/>
        </div>
    )
  }
}

export default Order