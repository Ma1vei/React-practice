import React, { Component } from 'react'

export class Categories extends Component {

    constructor(props) {
        super(props)
        this.state = {
            categories: [
                {
                    name: 'всё',
                    key: 'all'
                },
                {
                    name: 'стулья',
                    key: 'chairs'
                },
                {
                    name: 'столы',
                    key: 'tables'
                },
                {
                    name: 'шкафы',
                    key: 'furnitures'
                },
                {
                    name: 'кровати',
                    key: 'beds'
                }
            ]
        }
    }

  render() {
    return (
      <div className='categ'>
        {this.state.categories.map(e => (
            <div key={e.key} onClick={() => this.props.chooseCategory(e.key)}>{e.name}</div>
        ))}
      </div>
    )
  }
}

export default Categories