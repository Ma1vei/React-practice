import Header from "./components/Header/Header"
import Teaching from "./components/TeachingSection"
import Deferences from "./components/Diferences"
import Intro from "./components/IntroSec"
import Tabs from "./components/TabsSec"
import Fedback from "./components/Fidback"

import { useState } from "react"
import { Fragment } from "react"
import Effects from "./components/Effects"

function App() {

  const [tab, setTab] = useState('effect')
  const [vis, setVis] = useState(true)

  // setTimeout(() => {
  //   setVis(false)
  // }, 2000);

  return (
    <>
      {vis && <Header />}
      <main>
        <Intro />
        
        <Tabs active={tab} onChange={(current) => setTab(current)} />

        {tab === 'main' && (
          <>
            <Teaching />
            <Deferences />
          </>
        )}

        {tab === 'feedback' && (
          <>
           <Fedback />
          </>
        )}

        {tab === 'effect' && (
          <>
           <Effects />
          </>
        )}
      </main>
  
    </>
  )
}

export default App
