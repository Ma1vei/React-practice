export const ways = [
    {
        title: 'eqqweqw',
        description: 'asdbjasdhasd',
    },
    {
        title: 'eqqweqw 22222',
        description: 'asdbjasdhasd 2222222',
    },
    {
        title: 'eqqweqw 333333',
     
        description: 'asdbjasdhasd 3333',
    },
    {
        title: 'eqqweqw444444444444444',
        description: 'asdbjasdhasd',
    },
    {
        title: 'eqqweqw5555555',
        description: 'asdbjasdhasd 2222222',
    },
    {
        title: 'eqqweqw 6666666',
        description: 'asdbjasdhasd 3333',
    }
]