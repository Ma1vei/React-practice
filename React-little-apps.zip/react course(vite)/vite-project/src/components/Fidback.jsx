import { use } from "react"
import Button from "./Button/Button"
import { useState } from "react"
import { useRef } from "react";


function StateVsRef() {
    const input = useRef()
    const [show, setShow] = useState(false)

    function onkdown(e) {
        if(e.key === 'Enter') {
            setShow(true)
        }
    }

    

    return(
        <div>
            <h3>input value: {show && input.current.value}</h3>
            <input 
                ref={input} 
                type="text" 
                onKeyDown={onkdown}
            />
        </div>
    )
}


export default function Fedback() {

    const [form, setForm] = useState({
        name: '',
        error: true,
        reason: 'help',
    })

    // const [name, setName] = useState('')
    // const [reason, setReason] = useState('help')
    // const [error, setError] = useState(true)

    function handlenamechange(e) {
        // setName(e.target.value);
        // setError(e.target.value.trim().length === 0)
        setForm(prev => ({
            ...prev,
            name: e.target.value,
            error: e.target.value.trim().length === 0,
        }))
    }

    function handlereasonchange(e) {
        // setReason(e.target.value);
    }

    function toggleError () {
        setError((prev) => !prev)
        setError((prev) => !prev)
    }

    return (
        <section>
            <h3>обратная связь</h3>

            <Button onClick={toggleError}>Toggle Error</Button>

            <form action="">
                <label htmlFor="name">ваше имя</label>
                <input type="text" className='control' id="name" value={form.name} onChange={handlenamechange} style={{
                    border: form.error ? '1px solid red' : null
                }}/>

                <label htmlFor="reason">причина обращения</label>
                <select id="reason"  className='control' value={form.reason} onChange={(event) => setForm(prev => ({...prev, reason: event.target.value}))}>
                    <option value="error">оштбка</option>
                    <option value="help">помощь</option>
                    <option value="suggest">подтвердить</option>
                </select>






                <Button disabled={form.error}>отправить</Button>
            </form>

            
           <StateVsRef />

        </section>
    )
}