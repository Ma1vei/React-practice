export default function LiElements(props) {
    return(
      <li>
        <p><strong>{props.title}</strong>{props.description}</p>
      </li>
    )
  }