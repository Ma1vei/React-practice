import classes from './Button.module.css'

export default function Button( {children, nameonclick, isActive, ...props} ){

    console.log(classes);

    return (
        <button className={isActive ? `${classes.button} ${classes.active}` : `${classes.button}`} onClick={nameonclick} {...props}>
            {children}
        </button>
    )
}