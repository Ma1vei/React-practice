import { useState } from "react"
import Button from "./Button/Button"

export default function Deferences() {

    const [ contentType, setContentType ] = useState(null)

    function handleClick(type) {
        setContentType(type)
    }

    return(
        <section>
        <Button isActive={contentType === 'way'} nameonclick={() => handleClick('way')}>подход</Button>
        <Button isActive={contentType === 'easy'} nameonclick={() => handleClick('easy')}>доступность</Button>


        { !contentType && <p>нажми</p>}
        { contentType && <p>{contentType}</p>}



      </section>
    )
}