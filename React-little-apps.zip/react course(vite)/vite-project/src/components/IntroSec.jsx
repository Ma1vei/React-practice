export default function Intro() {
    return(
        <section>
            <h1 className="centered">Lorem ipsum dolor sit amet.</h1>
            <h3 className="centered" style={{color: '#666'}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit provident architecto, aliquid pariatur corrupti quia alias libero quisquam iste quasi.</h3>
        </section>
    )
}

