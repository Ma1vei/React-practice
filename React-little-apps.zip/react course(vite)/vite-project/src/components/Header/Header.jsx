import logo from '/cheef.svg'
import { useEffect, useState } from 'react'
import {styled} from 'styled-components'
// import './Header.css'


const HeaderContainer = styled.header`
  height: 50px;
  display: flex;
  justify-content: space-between;
`


export default function Header() {
    const [time, setTime] = useState(new Date())


    useEffect(() => {
      const interval =  setInterval(() => setTime(new Date()),1000)

      return() => {
        clearInterval(interval)
      }
    }, [])


    return(
      <HeaderContainer>
          
          <span>time now: {time.toLocaleTimeString()}</span>
      </HeaderContainer>
    )
}