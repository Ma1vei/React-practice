import { ways } from "../data"
import LiElements from "./LiElements"



export default function Teaching() {
    return(
        <section>
          <h3>наш подход</h3>
          <ul>
            {ways.map((way) => (
              <LiElements key={way.title} {...way} />
            ))}

          </ul>
        </section>
    )
}