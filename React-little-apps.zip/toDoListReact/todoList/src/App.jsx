import { useState } from 'react'
import { useEffect } from 'react'
import './App.css'

function App() {
  const [tasks, setTasks] = useState([])
  const [input, setInput] = useState('')
  const [addtaskbtn, setAddTask] = useState(false)

  const HandleInput = (e) => {
    setInput(e.target.value)
  }

  useEffect(() => {
    const input = document.querySelector('.input')
    const keypress = (event) => {
      if(event.key === 'Enter') {
        const newBlock = [...tasks, input.value]
        setTasks(newBlock)
      }
    }
    document.addEventListener('keypress', keypress)
    return () => document.removeEventListener('keypress', keypress)
  }, [input])


  const HandleDelete = (index) => {
    const newArray = [...tasks];
    newArray.splice(index, 1);
    setTasks(newArray)
  }


  return (
    <>
      <div className='Todolist' style={{width: '100%', textAlign: 'center', paddingTop: '100px'}}>
        <h1>Это TodoList на React. Ущербный но мне пох</h1>
        <div className="addTask">
          <input className='input' onChange={(e) => HandleInput(e)} value={input} type="text" placeholder='Введите ваше задание'/>
          <button onClick={() => {
            const newBlock = [...tasks, input]
            setTasks(newBlock)
          }}>Добавить</button>
        </div>
        <div className='tasks' style={{display:'flex', justifyContent:'center', flexDirection:'column', marginLeft:'210px'}}>
          {tasks.map((e, index) => {
            return ( <div key={index} style={{display:'flex', alignItems:"center", justifyContent: 'space-between', width: '300px'}}>
              <p>{e}</p> 
              <div>
                <input type="checkbox" name="" id="" />
                <button onClick={() => HandleDelete(index)}>Удалить</button>
              </div>
            </div>
            )
            })}
        </div>
      </div>
    </>
  )
}

export default App
