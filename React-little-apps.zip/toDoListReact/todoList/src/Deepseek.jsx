import { useState, useEffect, act } from 'react';
import './App.css';

function Deepseek() {
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState('');
  const [filter, setFilter] = useState([]);

  let copyTasks = tasks

  const HandleInput = (e) => {
    setInput(e.target.value);
  };

  useEffect(() => {
    const input = document.querySelector('.input');
    const keypress = (event) => {
      if(event.key === 'Enter' && input.value.trim()) {
        const newTask = { text: input.value, completed: false, active: true };
        setTasks([...tasks, newTask]);
        setFilter([...filter, newTask])
        setInput('');
      }
    };
    document.addEventListener('keypress', keypress);
    return () => document.removeEventListener('keypress', keypress);
  }, [tasks]);

  const HandleDelete = (index) => {
    const newArray = [...tasks];
    newArray.splice(index, 1);
    setTasks(newArray)
    setFilter(newArray)
  }

  const toggleComplete = (index) => {
    const updatedTasks = tasks.map((task, i) => 
      i === index ? { ...task, completed: !task.completed, active: !task.active } : task
    )
    updatedTasks.sort((a, b) => 
      b.completed - a.completed || filter.indexOf(a) - filter.indexOf(b)
    );
    setTasks(updatedTasks)
    setFilter(updatedTasks)
  };

  // Сортируем задачи: выполненные вверху
  let sortedTasks = [...filter].sort((a, b) => 
    b.completed - a.completed || filter.indexOf(a) - filter.indexOf(b)
  );

  
  const HandleFilter = (index) => {
    switch(index) {
      case 'All' : 
        copyTasks = tasks
        setFilter(copyTasks)
      break;
      case 'Active' : 
        copyTasks = sortedTasks.filter(e => e.active == true);
        setFilter(copyTasks)
      break;
      case 'NoActive' :
        copyTasks = sortedTasks.filter(e => e.active == false);
        setFilter(copyTasks)
      break
    }
  }


  return (
    <>
      <div className='Todolist' style={{width: '100%', textAlign: 'center', paddingTop: '100px'}}>
        <h1>Это TodoList на React. Улучшенный вариант</h1>
        <div className="addTask">
          <input 
            className='input' 
            onChange={HandleInput} 
            value={input} 
            type="text" 
            placeholder='Введите ваше задание'
          />
          <button onClick={() => {
            if(input.trim()) {
              const newTask = { text: input, completed: false, active: true };
              setTasks([...tasks, newTask]);
              setInput('');
            }
          }}>Добавить</button>
        </div>
        <div className='tasks' style={{display:'flex', justifyContent:'center', flexDirection:'column', marginLeft:'210px'}}>
          {filter.map((task, index) => (
            <div 
              key={index} 
              style={{
                display: 'flex',
                alignItems: "center",
                justifyContent: 'space-between',
                width: '300px',
                textDecoration: task.completed ? 'line-through' : 'none',
                opacity: task.completed ? 0.7 : 1
              }}
            >
              <p>{task.text}</p> 
              <div>
                <input 
                  type="checkbox" 
                  checked={task.completed}
                  onChange={() => toggleComplete(tasks.indexOf(task))}
                />
                <button onClick={() => HandleDelete(tasks.indexOf(task))}>Удалить</button>
              </div>
            </div>
          ))}
        </div>
      <button onClick={() => HandleFilter('All')}>Все</button>
      <button onClick={() => HandleFilter('Active')}>Активные</button>
      <button onClick={() => HandleFilter('NoActive')}>Выполненые</button>
      </div>
    </>
  );
}

export default Deepseek;