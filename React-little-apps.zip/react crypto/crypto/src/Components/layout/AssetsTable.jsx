import { Table } from 'antd'
import React, { useContext } from 'react'
import CryptoContext from '../../context/crypto-context';

const columns = [
    {
        title: 'Name',
        dataIndex: 'name',
        defaultSortOrder: 'descend',
        sorter: (a, b) => a.name.length - b.name.length,
    },
    {
      title: 'Price, $',
      dataIndex: 'price',
      sorter: (a, b) => a.price - b.price,
      sortDirections: ['descend'],
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      sorter: (a, b) => a.amount - b.amount,
      sortDirections: ['descend'],
    },
  ];


export default function AssetsTable() {
    const {crypto, assets} = useContext(CryptoContext)

    const data = assets.map(a => ({
        key: a.id,
        name: a.name,
        price: a.price,
        amount: a.amount
    }))

    return (
        <Table
            pagination={false}
            columns={columns}
            dataSource={data}
            showSorterTooltip={{
            target: 'sorter-icon',
            }}
        />
  )
}
