import React, { useContext } from 'react'
import { Layout, Spin } from 'antd';
import AppHeader from './Header';
import AppSlider from './Slider';
import AppContent from './Content';
import CryptoContext from '../../context/crypto-context';

export default function AppLayout() {

  const { load } = useContext(CryptoContext)

  if(load) {
    return  <Spin fullscreen />
  }
  
  return (
    <Layout>
        <AppHeader />
          <Layout>
            <AppSlider />
            <AppContent />
          </Layout>
    </Layout>
  )
}
