import { createContext } from "react";
import { useState } from "react";
import { useEffect } from "react";
import { fakeFetch, fakeFetchA } from "../api";
// import { fakeFetch, fakeFetchA } from '../api'

const CryptoContext = createContext({
    assets: [],
    crypto: [],
    load: false,
})


function percent(a, b) {
    return +(100 * Math.abs((a - b) / ((a + b) / 2))).toFixed(2)
}

export function CryptoContextProvider({children}) {


    const [load, setLoad] = useState(false)
    const [assets, setAsets] = useState([])
    const [crypto, setCrypto] = useState([])

    function mapAssets(assets, result) {
        return assets.map(asset => {
            const coin = result.find((c) => c.id === asset.id)
            return {
                grow: asset.price < coin.price,
                growPercent: percent(asset.price, coin.price),
                totalAmount: asset.amount * coin.price,
                totalProfit: asset.amount * coin.price - asset.amount * asset.price,
                name: coin.name,
                ... asset
            }
        })
    }

    useEffect(() => {
        async function preload() {
            setLoad(true)
            const result = await fakeFetch()
            const assets = await fakeFetchA()

            setAsets(mapAssets(assets, result))
            setCrypto(result)
            setLoad(false)
        }
       
        preload()
    }, [])

    function addAsset(newAsset) {
        setAsets((prev) => mapAssets([... prev, newAsset], crypto))
    }

    return <CryptoContext.Provider value={{load, crypto, assets, addAsset}}>
        {children}
    </CryptoContext.Provider>
}

export default CryptoContext