import { cryptoAssets, cryptoData } from './data'

const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      'X-API-KEY': 'PTL365k8KMO/PRt8XULh2f/ooqNp21HOulw2NCwJ0zg='
    }
  };
 
   
  


export function fakeFetch() {
    return (
        fetch('https://openapiv1.coinstats.app/coins', options)
        .then(res => res.json())
        .then(res => {
            return res.result
        })
    )
}

export function fakeFetchA() {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve(cryptoAssets)
        }, 1)
    })
}
