import React, { useEffect, useState } from 'react'


export default function Calculator() {

    const [button, setButton] = useState([]);
    const [number, setNumber] = useState('');
    const [result, setResult] = useState(0);

    useEffect(() => {
        let arrButtons = []
        for(let value = 0; value <= 9; value++) {
            arrButtons[value] = value
        }
        setButton(arrButtons)
    }, [])






  return (

    <div>
        <div className="output">
            <input type="text" defaultValue={number}/>
        </div>
        <div className="buttons">
            
            {
            button.map((e) => {
                return <button onClick={() => {

                    setNumber(number+e);
                }}>{e}</button>
            })}

        </div>
        <div className='func'>
            <button className='plus' onClick={() => {
                setNumber(number+'+');
            }}>+</button>
            <button className='minuse' onClick={() => {
                setNumber(number+'-')
            }}>-</button>
            <button className='delit' onClick={() => {
                setNumber(number+'/')
            }}>/</button>
            <button className='umnoz' onClick={() => {
                setNumber(number+'*')
            }}>*</button>
        </div>
        <button onClick={() => {
            try {
                setResult(eval(number))
            } catch (error){
                setResult('error')
            }
        }}>=</button>
        <div>
            <button onClick={() => {
                setNumber('')
                setResult(0)
            }}>C</button>  
            <button onClick={(e) => {setNumber(number.slice(0, -1))}}>DE</button> 
        </div>
        <div className="result">
            {result}
        </div>
    </div>
  )
}
