import React, { useEffect } from 'react'
import NewsBanner from '../components/NewsBanner'
import { getNews } from '../api/apiNews'
import { useState } from 'react'

import NewsList from '../components/NewsList'
import Skeleton from '../components/Skeleton'

export default function Main() {

  const [news, setNews] = useState([])
  const [isload, setIsload] = useState(true)

  useEffect(() => {
    const fetchNews = async () => {
      try {
        setIsload(true)
        const response = await getNews()
        setNews(response.news)
        setIsload(false)
      } catch(error) {
        console.log(error)
      }
    }
    fetchNews()
  }, [])


  return (
    <main className='main'>
        { <NewsBanner item={news[0]}></NewsBanner> }

        {!isload ? <NewsList news={news}/> : <Skeleton count={1} type={'item'}></Skeleton>}
    </main>
  )
}