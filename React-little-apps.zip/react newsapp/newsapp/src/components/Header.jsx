import React from 'react'


export default function Header() {

    const options = {
        weekday: 'long',
        day: 'numeric',
        year: 'numeric',
        month: 'long'
    }

    const date = new Date()

  return (
    <header className='header'>
        <h1 className='title'>News</h1>
        <p className='p'>{date.toLocaleDateString('en-US', options)}</p>
    </header>
  )
}
