import React from 'react'

export default function NewsItem({item}) {
  return (
    <li className='itemList'>
        <div className='stylesWrapper' style={{backgroundImage: `url(${item.image})`}}>
          
        </div>
        <div className='ing'>
          <h3 className='titleBanner2'>{item.title}</h3>
          <p className='extra2'>6h ago by {item.author}</p>
        </div>
    </li>
  )
}
