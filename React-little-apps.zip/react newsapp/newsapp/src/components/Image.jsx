import React from 'react'

export default function Image({image}) {
  return (
    <div className='wrapper'>
        {image ? <img src={image} className='imgbanner'></img> : null}
    </div>
  )
}
