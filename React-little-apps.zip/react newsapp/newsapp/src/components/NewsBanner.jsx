import React from 'react'
import Image from './Image'

export default function NewsBanner({item}) {

  return (
    <div className='banner'>
        <Image image={item.image}></Image>
        <h3 className='titleBanner'>{item.title}</h3>
        <p className='extra'>6h ago by {item.author}</p>
    </div>
  )
}
