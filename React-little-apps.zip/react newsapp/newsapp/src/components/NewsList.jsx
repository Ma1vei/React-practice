import React from 'react'
import NewsItem from './NewsItem'

export default function NewsList({news}) {
  return (
    <ul className='list'>
        {news.map((item) => {
            return <NewsItem key={item.id} item={item}/>
        })}
    </ul>
  )
}
